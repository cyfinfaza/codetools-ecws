import java.util.ArrayList;
import java.util.List;

public class Main
{
	public static void main(String[] args)
	{
		List<String> wordList = new ArrayList<String>();
		wordList.add("AP");
		wordList.add("COMP");
		wordList.add("SCI");
		wordList.add("ROCKS");
		System.out.println(StringFormatter.format(wordList,20));
		
		wordList.clear();
		wordList.add("GREEN");
		wordList.add("EGGS");
		wordList.add("AND");
		wordList.add("HAM");
		System.out.println(StringFormatter.format(wordList,20));
		
		wordList.clear();
		wordList.add("BEACH");
		wordList.add("BALL");
		System.out.println(StringFormatter.format(wordList,20));
		
		
	}
}