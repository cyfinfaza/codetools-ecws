https://secure-media.collegeboard.org/digitalServices/pdf/ap/ap16_frq_computer_science_a.pdf

The correct answer outputs should be as follows.

AP--COMP--SCI--ROCKS

GREEN--EGGS--AND-HAM

BEACH-----------BALL


NOTE: Using dashes instead of spaces so you can tell how many there are.

