import java.util.List;

// import com.sun.xml.internal.ws.api.streaming.XMLStreamReaderFactory.Woodstox;

public class StringFormatter
{
	public static int totalLetters(List<String> wordList) 
	{
    int sum = 0;
	  for(int i = 0; i<wordList.size(); i++){
      String string = new String(wordList.get(i));
      sum+=string.length();
    }
    return sum;
	}
	
	public static int basicGapWidth(List<String> wordList, int formattedLen)
	{
    return (formattedLen-totalLetters(wordList))/formattedLen;
	}
	
	public static String format(List<String> wordList, int formattedLen) 
	{
		int gap = basicGapWidth(wordList, formattedLen);
    int leftOver = leftoverSpaces(wordList, formattedLen);
    String output = "";
    for(int i = 0; i<wordList.size(); i++){
      output+=wordList.get(i);
      for(int b = 0; i<gap; i++) output+="-";
      if(leftOver>0){
        output+="-";
        leftOver--;
      }
    }
    return output;
	}
	
	public static int leftoverSpaces(List<String> wordList, int formattedLen)
	{
		int spacesLeft = formattedLen - totalLetters(wordList);
		int leftOver = spacesLeft%(basicGapWidth(wordList,formattedLen)*(wordList.size()-1));
		return leftOver;
	}
	
}